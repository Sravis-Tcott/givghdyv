   _____  ____  _    _ _   _______       _  ________ _____     __      ____ 
  / ____|/ __ \| |  | | | |__   __|/\   | |/ /  ____|  __ \    \ \    / /_ |        Soultaker Multitool V1 | Made by:
 | (___ | |  | | |  | | |    | |  /  \  | ' /| |__  | |__) |    \ \  / / | |        ~ Dasherr#4878               
  \___ \| |  | | |  | | |    | | / /\ \ |  < |  __| |  _  /      \ \/ /  | |        ~ @dasherrtecom
  ____) | |__| | |__| | |____| |/ ____ \| . \| |____| | \ \       \  /   | |
 |_____/ \____/ \____/|______|_/_/    \_\_|\_\______|_|  \_\       \/    |_|
                                                                                                                                                                                                                                                                                                                                                                                                           
                                          .""--..__
                     _                     []       ``-.._                   1. Pinger                                    16. Random Ip Generator
                  .'` `'.                  ||__           `-._               
                 /    ,-.\                 ||_ ```---..__     `-.            2. Ip Stresser                               17. Steam Account Generator
                /    /:::\\               /|//}          ``--._  `.           
                |    |:::||              |////}                `-. \         3. Ip Lookup                                 18. Minecraft & Spotify Generator
                |    |:::||             //'///                    `.\        
                |    |:::||            //  ||'                      `|       4. Port Scanner                              19. Rat Tutorial
                /    |:::|/        _,-//\  ||                             
               /`    |:::|`-,__,-'`  |/  \ ||                                5. Open Putty                                20. Sick Fonts (Text etc.)
             /`  |   |'' ||           \   |||                            
           /`    \   |   ||            |  /||                                6. Dox Tool                                  21. Phone Spoofer (SSL)
         |`       |  |   |)            \ | ||                        
        |          \ |   /      ,.__    \| ||                                7. USA Fake Info Generator                   22. Sms Bomber (iOS)
        /           `         /`    `\   | ||
       |                     /        \  / ||                                8. 30+ Phishing Sites                        23. Ip-Logger
       |                     |        | /  ||
       /         /           |        `(   ||                                9. Extreme Doxing Tool                       24. Botting Panel (All Socials)
      /          .           /             ||
     |            \          |             ||                                10. Rat/Virus Creator (Github)               25. Instagram ID Searcher
    /             |          /             ||               
   |\            /          |              ||                                11. Keyword Generator Tool                   26. Fortnite Aimbot/Wallhack
   \/`-._       |           /              ||
    //   `.    /`           |              ||                                12. Vpn/Ovh                                  27. EXIT
   //`.    `. |             \              ||
  ///\ `-._  )/             |              ||                                13. Open Cyberhub (Hacking Tools And More)   ~ Don't Resell This Tool ~
 //// )   .(/               |              ||
 ||||   ,'` )               /              //                                14. Open Vedbex (USEFUL TOOLS)               ~ Don't credit it to your own ~
 ||||  /                    /             || 
 `\\` /`                    |             //                                 15. Ascii Art                                ~ Enjoy! :) ~
     |`                     \            ||  
    /                        |           //  
  /`                          \         //   
/`                            |        ||    
`-.___,-.      .-.        ___,'        (/    